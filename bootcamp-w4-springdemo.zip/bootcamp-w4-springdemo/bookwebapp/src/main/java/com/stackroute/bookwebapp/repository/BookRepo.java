package com.stackroute.bookwebapp.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import com.stackroute.bookwebapp.model.Book;

public class BookRepo {

	List<Book> books;
	
	public BookRepo()
	{
		books=new ArrayList<Book>();
	}
	
	public void addBook(Book bobj)
	{
		books.add(bobj);
	}
	
	public List<Book> getBooks()
	{
		return books;
	}
	
	public boolean deleteBook(int bookid)
	{
		
		ListIterator<Book> iterator=books.listIterator();
		
		while(iterator.hasNext())
		{
			Book curbook=iterator.next();
			if(curbook.getBookid()==bookid)
			{
				iterator.remove();
			  return true;
			}
				
		}
		
		return false;
		
	}
	
	public Book findByBookid(int bookid)
	{
		
	Book bookresult=null;
ListIterator<Book> iterator=books.listIterator();
		
		while(iterator.hasNext())
		{
			Book curbook=iterator.next();
			if(curbook.getBookid()==bookid)
			{
		  bookresult=curbook;
	     }
			
		}
		return bookresult;
	
}
	
	public void updateBook(Book bookupdate)
	{
		
//		Book bookexist=findByBookid(bookupdate.getBookid());
//		bookexist.setAuthor(bookupdate.getAuthor());
//		bookexist.setBookname(bookupdate.getBookname());
		
		
ListIterator<Book> iterator=books.listIterator();
		
		while(iterator.hasNext())
		{
			Book curbook=iterator.next();
			if(curbook.getBookid()==bookupdate.getBookid())
			{
				//iterator.remove();
			    curbook.setAuthor(bookupdate.getAuthor());
			    curbook.setBookname(bookupdate.getBookname());
			    
			}
				
		}
		
		
		
		
	}
	
}