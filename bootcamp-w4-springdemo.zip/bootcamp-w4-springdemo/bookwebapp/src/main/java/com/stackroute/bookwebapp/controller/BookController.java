package com.stackroute.bookwebapp.controller;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.stackroute.bookwebapp.model.Book;
import com.stackroute.bookwebapp.repository.BookRepo;

@Controller

public class BookController {
	
	ApplicationContext ctx=new ClassPathXmlApplicationContext("beans.xml");
	BookRepo repo=ctx.getBean("bookrepobean",BookRepo.class);
	
	
	
	
	@GetMapping("/")
	public String gethome(ModelMap map)
	{
		List<Book> booklist=repo.getBooks();
		map.addAttribute("allbooks",booklist);
		
		return "index";
	}
	
	@PostMapping("/addbook")
	public String addbookhandler(@ModelAttribute("book") Book bookobj,ModelMap map)
	{
		
		repo.addBook(bookobj);
	 return "redirect:/";
		
	}
	
	@RequestMapping("/deletebook")
	public String deletebookhandler(@RequestParam("mybookid") String bookid,ModelMap map)
	{
		int bid=Integer.parseInt(bookid);
		
		repo.deleteBook(bid);
	   return "redirect:/";
		
	}
	
	@RequestMapping("/modifybook")
	public String getbook(@RequestParam("mybookid") String bookid,ModelMap map)
	{
		Book bookfound=repo.findByBookid(Integer.parseInt(bookid));
		List<Book> booklist=repo.getBooks();
		map.addAttribute("allbooks",booklist);
		
		map.addAttribute("ebook",bookfound);
		
		return "index";
		
	}
	
	
	@RequestMapping("/updatebook")
	public String updatebook(@ModelAttribute("bookupd") Book bookupd)
	{
		repo.updateBook(bookupd);
		
		return "redirect:/";
		
	}
	
	

}
