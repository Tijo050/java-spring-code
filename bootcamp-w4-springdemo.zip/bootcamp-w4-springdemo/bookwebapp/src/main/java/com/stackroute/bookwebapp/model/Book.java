package com.stackroute.bookwebapp.model;

import java.time.LocalDateTime;

public class Book {

		int bookid;
	String bookname;
	String author;
	LocalDateTime time;
	Book()
	{
		this.time=LocalDateTime.now();
		
	}
	public int getBookid() {
		return bookid;
	}
	public void setBookid(int bookid) {
		this.bookid = bookid;
	}
	public String getBookname() {
		return bookname;
	}
	public void setBookname(String bookname) {
		this.bookname = bookname;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	
	public String toString()
	{
		return "book id " + bookid + "bookname" + bookname + " author " + author ;
	}
	
}
