package com.stackroute.webjavaapp.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages="com.stackroute.webjavaapp")

public class MyDispatcherConfig {
	
	@Bean
	
	public InternalResourceViewResolver getresolver()
	{
		InternalResourceViewResolver isrobj=new InternalResourceViewResolver();
		isrobj.setPrefix("/WEB-INF/views/");
		isrobj.setSuffix(".jsp");
		return isrobj;
	}

}
