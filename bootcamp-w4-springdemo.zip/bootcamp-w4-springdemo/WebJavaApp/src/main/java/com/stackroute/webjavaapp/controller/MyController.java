package com.stackroute.webjavaapp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MyController {
	
	
	@GetMapping("/")
	public String gethome()
	{
		return "index";
	}

}
