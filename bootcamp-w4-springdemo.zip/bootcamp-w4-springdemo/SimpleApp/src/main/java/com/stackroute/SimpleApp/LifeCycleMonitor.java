package com.stackroute.SimpleApp;

import org.springframework.beans.factory.config.BeanPostProcessor;

public class LifeCycleMonitor implements BeanPostProcessor {

	public Object postProcessBeforeInitialization(Object bean, String beanName)
	{
		System.out.println("current bean in before intialize" + beanName );
		Project project;
		
		if(beanName.equals("projectbean"))
		{
			project=(Project)bean;
			project.setDescription("Insurance");
			return project;
			
		}
		return bean;
	}
	
	public Object postProcessAfterInitialization(Object bean, String beanName)
	{

		System.out.println("current bean in after initialize " + beanName );
		return bean;
	}

}
