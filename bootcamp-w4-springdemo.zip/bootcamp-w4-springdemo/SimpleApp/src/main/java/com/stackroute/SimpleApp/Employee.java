package com.stackroute.SimpleApp;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

public class Employee {
 int id;
 String name;
 Map address;
 

 Project project;
 

 
 

 
 public Map getAddress() {
	return address;
}
public void setAddress(Map address) {
	this.address = address;
}
Employee()
 {
	 
 }

@Autowired
 Employee(Project projobj)
 {
	 this.project=projobj;
 }
 
 
public Project getProject() {
	return project;
}
public void setProject(Project project) {
	this.project = project;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
 
	
}
