package com.stackroute.SimpleApp;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        
     //   Employee emp=new Employee(); 
        
        ApplicationContext appcontext=new ClassPathXmlApplicationContext("bean2.xml");
        
        Production prodobj=appcontext.getBean("prodbean",Production.class);
        //prodobj.getProject().setDescription("online class");
        
        System.out.println("Project in Production : " + prodobj.getProject().getDescription()); 
        
        
        
        Employee emp=appcontext.getBean("empbean3",Employee.class); //container provides instance 
        
        System.out.println("Welcome " + emp.getName());
       // emp.getProject().setDescription("movie booking");
        
        System.out.println("Employee Project details " + emp.getProject().getDescription());
        
    
        
      
        
    }
}
