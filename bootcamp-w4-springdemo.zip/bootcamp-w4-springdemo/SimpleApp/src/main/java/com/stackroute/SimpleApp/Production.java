package com.stackroute.SimpleApp;

import org.springframework.beans.factory.annotation.Autowired;

public class Production {
String manager;

@Autowired
Project project;


public String getManager() {
	return manager;
}
public void setManager(String manager) {
	this.manager = manager;
}
public Project getProject() {
	return project;
}
public void setProject(Project project) {
	this.project = project;
}



}
