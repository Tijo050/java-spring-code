package com.stackroute.hotelrelation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelRelationApplicationTests {

	@Test
	void contextLoads() {
	}

}
