package com.stackroute.hotelrelation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stackroute.hotelrelation.model.Customer;
import com.stackroute.hotelrelation.repository.CustomerRepo;


@Service

public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerRepo repo;
	
	@Override
	public Customer addCustomer(Customer cust) {
 
		Customer custresult=repo.save(cust);
		
		return custresult;
	}

	@Override
	public List<Customer> viewCustomers() {
 
		List<Customer> customers=repo.findAll();
		
		return customers;
	}

}
