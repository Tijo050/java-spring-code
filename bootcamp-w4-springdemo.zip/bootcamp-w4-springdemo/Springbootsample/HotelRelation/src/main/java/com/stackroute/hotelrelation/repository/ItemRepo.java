package com.stackroute.hotelrelation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.stackroute.hotelrelation.model.Item;
@Repository
@Transactional
public interface ItemRepo extends JpaRepository<Item,Integer>{

}
