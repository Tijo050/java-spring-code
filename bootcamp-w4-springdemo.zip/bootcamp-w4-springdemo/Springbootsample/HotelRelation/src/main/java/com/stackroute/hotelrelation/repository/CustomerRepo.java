package com.stackroute.hotelrelation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.stackroute.hotelrelation.model.Customer;

@Repository
@Transactional
public interface CustomerRepo  extends JpaRepository<Customer,String>{

}
