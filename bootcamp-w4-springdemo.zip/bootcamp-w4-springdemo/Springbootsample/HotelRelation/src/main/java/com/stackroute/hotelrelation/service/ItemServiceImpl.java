package com.stackroute.hotelrelation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stackroute.hotelrelation.model.Item;
import com.stackroute.hotelrelation.repository.ItemRepo;

@Service

public class ItemServiceImpl implements ItemService {

	@Autowired
	ItemRepo repo;
	
	
	@Override
	public Item addItem(Item itemnew) {

	Item itemobj=repo.save(itemnew);
	return itemobj;
	}

	@Override
	public List<Item> viewitems() {

		List<Item> items=repo.findAll();

		return items;
	}

	
}
