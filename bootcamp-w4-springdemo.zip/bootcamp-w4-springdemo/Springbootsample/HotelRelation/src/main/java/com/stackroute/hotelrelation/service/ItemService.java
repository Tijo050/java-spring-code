package com.stackroute.hotelrelation.service;

import java.util.List;

import com.stackroute.hotelrelation.model.Item;

public interface ItemService {

	Item addItem(Item itemnew);
	List<Item> viewitems();
}
