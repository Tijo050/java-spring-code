package com.stackroute.hotelrelation.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stackroute.hotelrelation.model.Item;
import com.stackroute.hotelrelation.service.ItemService;

@RestController
@RequestMapping("hotel/item")
public class ItemController {
	
	@Autowired
	ItemService itemserve;
	
	@RequestMapping("/additem")
	public ResponseEntity<?> additem(@RequestBody Item itemnew)
	{
	Item itemresult=itemserve.addItem(itemnew);
	return new ResponseEntity<Item>(itemresult,HttpStatus.CREATED);
	}
	
   @GetMapping("/viewitems")
   public ResponseEntity<?> getitem()
   {
	   List<Item> items=itemserve.viewitems();
	   return new ResponseEntity<List<Item>> (items,HttpStatus.OK);
	   
   }
	
	
}
