package com.stackroute.hotelrelation.service;

import java.util.List;

import com.stackroute.hotelrelation.model.Customer;

public interface CustomerService {

	Customer addCustomer(Customer cust);
	List<Customer> viewCustomers();
	
	
}
