package com.stackroute.productapp.service;

import java.util.List;

import com.stackroute.productapp.exception.BillNotFoundException;
import com.stackroute.productapp.model.Bill;
import com.stackroute.productapp.model.Item;

public interface ProductService {
	
	Bill addBill(Bill bill);
	
	List<Bill> viewbills();
	
	List<Item> viewitems(String billid) throws BillNotFoundException;
	
	boolean deleteBill(String billid) throws BillNotFoundException;
	
	boolean deleteItem(String billid, String itemid) throws BillNotFoundException;
	
	
	

}
