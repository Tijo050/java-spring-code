package com.stackroute.productapp.exception;

public class ItemAlreadyExistException extends Exception{
	
	public ItemAlreadyExistException(String msg)
	{
		super(msg);
	}

}
