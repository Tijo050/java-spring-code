package com.stackroute.productapp.service;

import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stackroute.productapp.exception.BillNotFoundException;
import com.stackroute.productapp.model.Bill;
import com.stackroute.productapp.model.Item;
import com.stackroute.productapp.repository.ProductRepo;

@Service
public class ProductServiceImpl implements ProductService{

	@Autowired
	ProductRepo repo;
	
	@Override
	public Bill addBill(Bill billnew) {
		
	Optional<Bill> billexist=repo.findById(billnew.getBillnumber());
		Bill result=null;
	
		if(billexist.isPresent())
		{
			Bill billobj=billexist.get();
			List<Item> existitem=billobj.getItems();
			
			List<Item> newitems=billnew.getItems();
			
			existitem.addAll(newitems);
			
			billobj.setItems(existitem);
			
			result=repo.save(billobj);
			
			
		}
		else
		 result=repo.save(billnew);
		
		
		
		
		return result;
	}

	@Override
	public List<Bill> viewbills() {

		
		return repo.findAll();
	}

	@Override
	public List<Item> viewitems(String billid) throws BillNotFoundException {
		
		Optional<Bill> billoptional=repo.findById(billid);
		
		if(billoptional.isPresent())
		{
			return billoptional.get().getItems();
		}

		else
		 throw new BillNotFoundException("billid doesnt exist");
	}
	

	@Override
	public boolean deleteBill(String billid) throws BillNotFoundException {

Optional<Bill> billoptional=repo.findById(billid);
		
		if(billoptional.isPresent())
		{
			repo.deleteById(billid);
			return true;
		}

		else
		 throw new BillNotFoundException("billid doesnt exist");
	
	}
	
	

	@Override
	public boolean deleteItem(String billid, String itemid) throws BillNotFoundException {
		
		Optional<Bill> billoptional= repo.findById(billid);
		

		if(billoptional.isPresent())
		{
			Bill billobj=billoptional.get();
			
			
			List<Item> existitems=billobj.getItems();
			
			Iterator<Item> iterator=existitems.iterator();
			while(iterator.hasNext())
			{
				Item itemobj=iterator.next();
				
				if(itemobj.getItemid().equals(itemid))
					iterator.remove();
				
			}
			
			
			billobj.setItems(existitems);
	        repo.save(billobj);		
			return true;
		}

		else
		
		 throw new BillNotFoundException("billid doesnt exist");
		 
		
	}
	
	

}
