package com.stackroute.productapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import com.stackroute.productapp.filter.ProductFilter;

@Configuration
@SpringBootApplication
public class ProductappApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductappApplication.class, args);
	}
	
	
	@Bean
	
	public FilterRegistrationBean getfilter()
	{
		
		UrlBasedCorsConfigurationSource urlconfig=new UrlBasedCorsConfigurationSource();
		
		CorsConfiguration cconfig=new CorsConfiguration();
		
		
		cconfig.setAllowCredentials(true);
	cconfig.addAllowedOrigin("*");
	cconfig.addAllowedMethod("*");
	cconfig.addAllowedHeader("*");

	
	urlconfig.registerCorsConfiguration("/**", cconfig);
	
	FilterRegistrationBean fbean=new FilterRegistrationBean(new CorsFilter(urlconfig));	
	
	fbean.setFilter(new ProductFilter());
	
	fbean.addUrlPatterns("/product/bill/*");
	
	return fbean;
	
		
		
		
		
	}
	
	
	

}
