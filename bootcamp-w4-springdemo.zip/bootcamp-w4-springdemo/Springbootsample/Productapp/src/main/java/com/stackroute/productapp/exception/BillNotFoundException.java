package com.stackroute.productapp.exception;

public class BillNotFoundException extends Exception {
	
	public BillNotFoundException(String msg)
	{
		super(msg);
	}

}
