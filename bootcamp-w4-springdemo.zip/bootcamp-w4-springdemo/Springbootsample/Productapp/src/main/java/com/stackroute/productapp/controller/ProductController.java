package com.stackroute.productapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stackroute.productapp.exception.BillNotFoundException;
import com.stackroute.productapp.model.Bill;
import com.stackroute.productapp.model.Item;
import com.stackroute.productapp.service.ProductService;

@RestController
@RequestMapping("product/bill")
public class ProductController {

	
	@Autowired
	ProductService pservice;
	
	@PostMapping("/addBill")
	public ResponseEntity<?> addbilldata(@RequestBody Bill billnew)

	{
		Bill result=pservice.addBill(billnew);
		
		return new ResponseEntity<Bill>(result,HttpStatus.CREATED);
		
	}
	
	@RequestMapping("/viewallbills")
	public ResponseEntity<?> getallbills()
	{
		List<Bill> bills=pservice.viewbills();
		return new ResponseEntity<List<Bill>>(bills,HttpStatus.OK);
	}
	
	
	@RequestMapping("/viewitems/{billno}")
	public ResponseEntity<?> getitems(@PathVariable("billno") String bno)
	{
		List<Item> items;
		try {
			items = pservice.viewitems(bno);
			return new ResponseEntity<List<Item>>(items,HttpStatus.OK);
		} catch (BillNotFoundException e) 
		{
			
			return new ResponseEntity<String>(e.getMessage(),HttpStatus.NOT_FOUND);
		}
		
	}
	@DeleteMapping("/deletebill/{billid}")
	public ResponseEntity<?> deleteallbill(@PathVariable("billid") String bno)
	{
		
		try
		{
			   pservice.deleteBill(bno);
			   return new ResponseEntity<String>("bill deleted",HttpStatus.OK);
		}
		catch (BillNotFoundException e) 
		{
			
			return new ResponseEntity<String>(e.getMessage(),HttpStatus.NOT_FOUND);
		}
	}
		
	@DeleteMapping("/deleteitem/{billid}/{itemid}")
	
	public ResponseEntity<?> deleteitemforbill(@PathVariable("billid") String bno,@PathVariable("itemid") String itemid)
	{
		
		try {
			pservice.deleteItem(bno, itemid);
			
			return new ResponseEntity<String>("bill deleted",HttpStatus.OK);
		} 
		catch (BillNotFoundException e) 
		{
			
			return new ResponseEntity<String>(e.getMessage(),HttpStatus.NOT_FOUND);
		}
		
		
	}
	
		
	
		
	}
	
	
	
	
	
	

