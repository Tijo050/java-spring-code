package com.stackroute.Springbootsample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootsampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
