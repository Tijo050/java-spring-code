package com.stackroute.restjpa.service;

import java.util.List;

import com.stackroute.restjpa.exception.BookAlreadyExistException;
import com.stackroute.restjpa.exception.BookNotFoundException;
import com.stackroute.restjpa.model.Ebook;

public interface BookService {

	Ebook addBook(Ebook book) throws BookAlreadyExistException;
	List<Ebook> viewBooks() ;
	
	Ebook findebook(String bookid) ;
	boolean deleteBook(String bookid) throws BookNotFoundException;
	
	Ebook updateBook(Ebook bookupd) throws BookNotFoundException;
	
	
	List<Ebook> getBookbyname(String name);
	
	List<Ebook> getlesspriceBook(int pri);
	
	
}
