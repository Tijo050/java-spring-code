package com.stackroute.restjpa.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import io.swagger.annotations.ApiModel;

import io.swagger.annotations.ApiModelProperty;

@ApiModel
@Entity
public class Ebook {
	
	
	@Id
	String bookid;
	
	 
	@ApiModelProperty("name of the book")
	String bookname;

	@ApiModelProperty("original price of book without tax")
	 int price;
	 
	
	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getBookid() {
		return bookid;
	}

	public void setBookid(String bookid) {
		this.bookid = bookid;
	}

	public String getBookname() {
		return bookname;
	}

	public void setBookname(String bookname) {
		this.bookname = bookname;
	}
	
	
	

}
