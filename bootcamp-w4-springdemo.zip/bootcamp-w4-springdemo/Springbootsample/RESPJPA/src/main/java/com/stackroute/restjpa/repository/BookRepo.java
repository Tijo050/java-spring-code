package com.stackroute.restjpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.stackroute.restjpa.model.Ebook;

 public interface BookRepo  extends JpaRepository<Ebook,String>{
	
	List<Ebook>  findByBookname(String bname);
	
	Ebook findByBooknameAndBookid(String bookname,String bookid);
	
	List<Ebook> findByPriceLessThan(int pri);
}

