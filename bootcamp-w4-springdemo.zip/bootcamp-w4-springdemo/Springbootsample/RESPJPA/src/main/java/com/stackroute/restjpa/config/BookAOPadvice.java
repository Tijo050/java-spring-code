package com.stackroute.restjpa.config;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.stackroute.restjpa.model.Ebook;

@Aspect
@Component
public class BookAOPadvice {
	
	Logger mylogger=LoggerFactory.getLogger(BookAOPadvice.class);
	
	@Before("addbookhandler()")
	public void addbookadvice(JoinPoint jp)
	{
	  mylogger.info("Customer is trying to add Book");
	  System.out.println(jp.getSourceLocation().toString());
	  
	  		
	}
	
	
	@Around("addbookhandler()")
	public Object aroundbookadd(ProceedingJoinPoint proceedobj) throws Throwable
	{
		 Object obj=proceedobj.proceed();
		 
		 ResponseEntity  res=(ResponseEntity) obj;
		 try
		 {
		Ebook ebook=(Ebook)res.getBody();
		mylogger.info("Client added book with name : " + ebook.getBookname() + " of price " + ebook.getPrice());
		 }
		 catch(Exception e)
		 {
			 mylogger.info("can not cast");
		 }
		
		return obj;
		
	}
	
	@AfterThrowing("execution (* com.stackroute.restjpa.controller.BookController.deletebook(..))")
	public void afterdelete()
	{
		mylogger.warn("Exception raised now due to invalid book idwhile deleting book");
		
		
	}
	
	
	@AfterThrowing(pointcut="addbookhandler()",throwing="myexception")
	public void addexcephandler(Exception myexception)
	{
		mylogger.info("exception raised" + myexception);
	}
	
	
	
	@After("execution (* com.stackroute.restjpa.controller.BookController.getbooks(..)) ")
	public void afterviewingBooks(JoinPoint jp) {
		System.out.println("Some one called view books method of this api");
	}
	
	
	
	@Pointcut("execution (* com.stackroute.restjpa.controller.BookController.addebook(..))")
	public void addbookhandler()
	{
	
	}
	
	@Pointcut("execution (* com.stackroute.restjpa.controller.BookController.deletebook(..))")
	public void deletebookhandler()
	{}

}
