package com.stackroute.restjpa.exception;

public class BookNotFoundException extends Exception{

	public BookNotFoundException(String msg)
	{
		super(msg);
	}
}
