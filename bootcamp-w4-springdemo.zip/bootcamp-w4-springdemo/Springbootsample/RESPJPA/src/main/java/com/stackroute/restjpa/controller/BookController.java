package com.stackroute.restjpa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stackroute.restjpa.exception.BookAlreadyExistException;
import com.stackroute.restjpa.exception.BookNotFoundException;
import com.stackroute.restjpa.model.Ebook;
import com.stackroute.restjpa.service.BookService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.ApiResponse;

@RestController
@RequestMapping("library/api")

public class BookController {
	
	
	
	@Autowired
	BookService bookservice;
	
	@ApiOperation("used to add new book")
	@PostMapping("/addbook")
	public ResponseEntity<?> addebook(@RequestBody Ebook booknew)
	{
	Ebook result;
	try {
		result = bookservice.addBook(booknew);
		return new ResponseEntity<Ebook>(result, HttpStatus.CREATED);
		
	} 
	catch (BookAlreadyExistException e)
	{  
		return new ResponseEntity<String>(e.getMessage(), HttpStatus.CONFLICT);
		 
	 }

	}
	
	
	@GetMapping("/viewbooks")
	public ResponseEntity<?> getbooks()
	{
		
		List<Ebook> ebooks=bookservice.viewBooks();
		return new ResponseEntity<List<Ebook>>(ebooks,HttpStatus.OK);
	}
	
	
	@ApiOperation(value="delete",response=Iterable.class)
	@ApiResponses(
			        value = {
			        		@ApiResponse(code=200,message="Book with given id is removed"),
			        		@ApiResponse(code=404,message="Given Bookid does not exist")
			        		
			        }
			
			    )
	@RequestMapping("/removebook/{bookid}")
	public ResponseEntity deletebook(@PathVariable("bookid") String bid)
	{
		try {
		bookservice.deleteBook(bid);
		return new ResponseEntity<String>("Deleted succssfyky",HttpStatus.OK);
		}
		catch(BookNotFoundException e)
		{
			return new ResponseEntity<String>(e.getMessage(),HttpStatus.NOT_FOUND);
		}
	}
	
	@RequestMapping("/updatebook")
	public ResponseEntity updatebook(@RequestBody Ebook bookupd)
	{
		try
		{
			Ebook bookupdated=bookservice.updateBook(bookupd);
			return new ResponseEntity<Ebook>(bookupdated, HttpStatus.OK);
		}
		catch(BookNotFoundException e)
		{
			return new ResponseEntity<String>(e.getMessage(),HttpStatus.NOT_FOUND);	
			
		}
	}
	
	
	@RequestMapping("/viewbyname/{bname}")
	public ResponseEntity<?> getbooks(@PathVariable("bname") String bn)
	{
		
		List<Ebook> books=bookservice.getBookbyname(bn);
		
		return new ResponseEntity<List<Ebook>>(books,HttpStatus.OK);
	}
	
	
	@RequestMapping("/getlowerprice/{pri}")
	
   public ResponseEntity<?> getlowpricebook(@PathVariable("pri") int price)
   {
		
		List<Ebook> books=bookservice.getlesspriceBook(price);
		
		return new ResponseEntity<List<Ebook>>(books,HttpStatus.OK);
   }

}
