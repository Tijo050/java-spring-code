package com.stackroute.restjpa.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stackroute.restjpa.exception.BookAlreadyExistException;
import com.stackroute.restjpa.exception.BookNotFoundException;
import com.stackroute.restjpa.model.Ebook;
import com.stackroute.restjpa.repository.BookRepo;

@Service
public class BookServiceImpl implements BookService {
	

	@Autowired
	BookRepo bookrepo;
	
	@Override
	public Ebook addBook(Ebook book) throws BookAlreadyExistException {
		
	Optional<Ebook> bookexist=bookrepo.findById(book.getBookid());
	
	if (bookexist.isPresent())
		throw new BookAlreadyExistException("bookid exist");
	
	
	Ebook obj=bookrepo.save(book);
			return obj;
	}

	@Override
	public List<Ebook> viewBooks() {
		
	List<Ebook> books=bookrepo.findAll();
		
		return books;
	}

	@Override
	public Ebook findebook(String bookid) {

  Optional<Ebook> bookopt=bookrepo.findById(bookid);
		
		if( bookopt.isPresent())
		return bookopt.get();
		else
			return null;
	}

	@Override
	public boolean deleteBook(String bookid) throws BookNotFoundException{
		
	 Ebook bookfound=findebook(bookid);
	 if(bookfound==null)
		 throw new BookNotFoundException("invalid id");
		
	 
		bookrepo.deleteById(bookid);
		return true;
	}

	@Override
	public Ebook updateBook(Ebook bookupd) throws BookNotFoundException {
		
		 Ebook bookfound=findebook(bookupd.getBookid());
		 if(bookfound==null)
			 throw new BookNotFoundException("invalid id");
		 
		
		 bookfound.setBookname(bookupd.getBookname());
		 
		 bookrepo.save(bookfound);
		 
		return bookfound;
	}

	@Override
	public List<Ebook> getBookbyname(String name) {
		 
		List<Ebook> books=bookrepo.findByBookname(name);
		
		return books;
	}

	@Override
	public List<Ebook> getlesspriceBook(int pri) {
		 
	List<Ebook>	books=bookrepo.findByPriceLessThan(pri);
	return books;
	}

}
