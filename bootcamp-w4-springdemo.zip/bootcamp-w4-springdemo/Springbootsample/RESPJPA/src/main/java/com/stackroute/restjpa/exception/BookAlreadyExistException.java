package com.stackroute.restjpa.exception;

public class BookAlreadyExistException extends Exception {

	
	public BookAlreadyExistException(String msg)
	{
		super(msg);
		
	}
}
