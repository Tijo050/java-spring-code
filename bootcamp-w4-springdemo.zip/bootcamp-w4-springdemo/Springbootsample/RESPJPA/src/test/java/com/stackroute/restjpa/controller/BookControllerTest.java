package com.stackroute.restjpa.controller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.stackroute.restjpa.exception.BookAlreadyExistException;
import com.stackroute.restjpa.model.Ebook;
import com.stackroute.restjpa.service.BookService;

@RunWith(SpringRunner.class)
@WebMvcTest
public class BookControllerTest {
	
	@Autowired
	MockMvc mockmvc;
	
	@InjectMocks
	BookController bookctrl;
	
	@MockBean
	BookService bookservice;
	
	Ebook book;
	
	@Before
	public void setp()
	{
		MockitoAnnotations.initMocks(this);
         mockmvc=MockMvcBuilders.standaloneSetup(bookctrl).build();
         
         book=new Ebook();
         book.setBookid("1200");
         book.setBookname("Robotics");
         book.setPrice(2300);
         
	}

	@Test
	public void addbookandreturnobject() throws Exception 
	{
		Mockito.when(bookservice.addBook(book)).thenReturn(book);
	
		mockmvc.perform(MockMvcRequestBuilders.post("/library/api/addbook")
				                               .contentType(MediaType.APPLICATION_JSON)
				                               .content(converobjtojson(book)))
												.andExpect(MockMvcResultMatchers.status().isCreated())
												.andDo(MockMvcResultHandlers.print());
		
		
		
		
	}
	
	
	public String converobjtojson(Object obj) throws JsonProcessingException
	{
		ObjectMapper objmap=new ObjectMapper();
		String output=objmap.writeValueAsString(obj);
		return output;
		
		
	}
	
	
}
