package com.stackroute.restjpa.repository;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;

import com.stackroute.restjpa.model.Ebook;

import junit.framework.Assert;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace=AutoConfigureTestDatabase.Replace.NONE)

public class BookRepoTest {

	@Autowired
	BookRepo repo;

	Ebook book;
	
	@Before
	public void initialize()
	{
		book=new Ebook();
		book.setBookid("b105");
		book.setBookname("Algorithm");
		book.setPrice(3000);
	}
	

	
	@Test
	//@Rollback(true)
	public void addbookwhencalledsave()
	{
		repo.save(book);
		
		Ebook result=repo.findByBooknameAndBookid("Algorithm","b105");
		
		Assert.assertEquals(result.getPrice(),3000);
		
		
	}

	
//	@Test
//	public void findbybooknameandidreturnsobject()
//	{
//		
//		Ebook result=repo.findByBooknameAndBookid("Algorithm","b105");
//		
//		Assert.assertEquals(result.getBookname(), "Algorithm");
// 		
//		
//	}
	
//	@Test
//	public void afterall()
//		{
//			//Ebook result=repo.findByBooknameAndBookid("Algorithm","b101");
//			repo.deleteById(book.getBookid());
//			Assert.assertEquals("b105", book.getBookid());
//		//	repo.delete(result);
//		}
	
}
