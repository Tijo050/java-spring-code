package com.stackroute.restjpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RespjpaApplicationTests {


 
    
    
    public static void main(String[] args) {
		SpringApplication.run(RespjpaApplication.class, args);
		System.out.println("Application started succesfully");
	}



// 	@Test
// 	void contextLoads() {
// 	}

}



