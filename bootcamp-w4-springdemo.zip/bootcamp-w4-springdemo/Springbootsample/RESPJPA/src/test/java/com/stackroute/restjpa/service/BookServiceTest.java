package com.stackroute.restjpa.service;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.stackroute.restjpa.exception.BookAlreadyExistException;
import com.stackroute.restjpa.model.Ebook;
import com.stackroute.restjpa.repository.BookRepo;

import junit.framework.Assert;

public class BookServiceTest {

	@Mock
	BookRepo bookrepo;
	
	@InjectMocks
	BookServiceImpl bookservice;
	
	Ebook book;
	
	@Before
	public void intialize()
	{
		MockitoAnnotations.initMocks(this);
		book=new Ebook();
		book.setBookid("101");
		book.setBookname("Disney world");
		book.setPrice(3000);
		
	}
	
	@Test
	public void whencalladdbooktobesaved() throws BookAlreadyExistException
	{
		Mockito.when(bookrepo.save(book)).thenReturn(book);
		
		Ebook bookobj=bookservice.addBook(book);
		
		Assert.assertEquals(bookobj.getBookname(), "Disney world");
		
	}
	
	
	
	
}
