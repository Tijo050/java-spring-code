package com.stackroute.authorizeapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthorizeappApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuthorizeappApplication.class, args);
	}

}
