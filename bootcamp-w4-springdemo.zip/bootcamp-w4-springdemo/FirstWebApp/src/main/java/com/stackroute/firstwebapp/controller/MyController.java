package com.stackroute.firstwebapp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.stackroute.firstwebapp.model.Employee;

@Controller
public class MyController {

	
	@GetMapping("/")
	public String showHome()
	{
		return "index";
	}

	@GetMapping("/login")
	public String showwelcome(@RequestParam("username") String uname,ModelMap mymap)
	{
		mymap.addAttribute("userkey",uname);
		
		if(uname.equals("Admin"))
		return "welcome";
		else
	return "error";
	}
	
	@PostMapping("/addemployee")
		public String addEmployee(@ModelAttribute("employee") Employee emp)
		{
		
		  System.out.println(emp.getEmpname());
		   return "welcome";
		
		}
	
		
		
	
	
	
	  
}
