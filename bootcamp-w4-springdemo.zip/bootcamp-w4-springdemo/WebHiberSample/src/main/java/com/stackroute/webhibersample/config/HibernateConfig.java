package com.stackroute.webhibersample.config;

import java.io.IOException;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;
import org.hibernate.SessionFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.stackroute.webhibersample.model.Player;

@Configuration
@EnableTransactionManagement

public class HibernateConfig {

	
	
/*
        Use this configuration while submitting solution in hobbes.
		dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
		dataSource.setUrl("jdbc:mysql://" + System.getenv("MYSQL_HOST") + ":3306/" + System.getenv("MYSQL_DATABASE")
				+"?verifyServerCertificate=false&useSSL=false&requireSSL=false");
		dataSource.setUsername(System.getenv("MYSQL_USER"));
		dataSource.setPassword(System.getenv("MYSQL_PASSWORD")); */

	
	@Bean
	public DataSource getDataSource()
	{
		BasicDataSource datasource=new BasicDataSource();
		datasource.setDriverClassName("com.mysql.cj.jdbc.Driver");
		datasource.setUrl("jdbc:mysql://localhost:3306/usthibernate");
		datasource.setUsername("root");
		datasource.setPassword("password");
		return datasource;
		
	}
	
	@Bean
	public LocalSessionFactoryBean getSessfact(DataSource datasour) throws Exception
	{
		
		
		LocalSessionFactoryBean sessfact=new LocalSessionFactoryBean();
		sessfact.setDataSource(datasour);
		Properties property=new Properties();
		property.put("hibernate.dialect","org.hibernate.dialect.MySQL5Dialect");
		property.put("hibernate.show_sql","true");
		property.put("hibernate.hbm2ddl.auto","update");
		sessfact.setHibernateProperties(property);
		sessfact.setAnnotatedClasses(Player.class);
        sessfact.afterPropertiesSet();
        
		return sessfact;
		
	}
	
	@Bean
	public HibernateTransactionManager getTransaction(SessionFactory sessfactory)
		{
	HibernateTransactionManager hibermanager=new HibernateTransactionManager();
	hibermanager.setSessionFactory(sessfactory);
	return hibermanager;
	
	}
}
