package com.stackroute.webhibersample.dao;

import java.util.List;

import com.stackroute.webhibersample.model.Player;

public interface PlayerDao {

	boolean addPlayer(Player playerobj);
	
	List<Player> getPlayers();
	
	Player findPlayerbyid(int playerid);
	
	boolean deletePlayer(int playerid);
	
	boolean updatePlayer(Player playertoup);
	
	
}


