package com.stackroute.webhibersample.model;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Player {
	
	LocalDateTime publish;
	public Player()
	{
		publish=LocalDateTime.now()
	}
	
     
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	 int playerid;
	 
	 public int getPlayerid() {
		return playerid;
	}
	public void setPlayerid(int playerid) {
		this.playerid = playerid;
	}
	String playername;
	String country;
	 
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getPlayername() {
		return playername;
	}
	public void setPlayername(String playername) {
		this.playername = playername;
	}
	 
	
}
