package com.stackroute.webhibersample.controller;

 
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.stackroute.webhibersample.dao.PlayerDao;
import com.stackroute.webhibersample.dao.PlayerDaoImpl;
import com.stackroute.webhibersample.model.Player;

@Controller
public class MyController {

	@Autowired
	PlayerDao playerdao;
	
	@GetMapping("/")
	public String gethome(ModelMap mymap)
	{
		List<Player> players=playerdao.getPlayers();
		mymap.put("playerslist",players);
		return "index";
	}
	
	@RequestMapping("/addplayer")
	public String saveplayer(@ModelAttribute("player") Player playernew)
	{
		
		
		playerdao.addPlayer(playernew);
		System.out.println("added");
		return "redirect:/";
	}
	
	@RequestMapping("/deleteplayer")
	public String deleteplayerhandler(@RequestParam("myid") int pid)
	{
		playerdao.deletePlayer(pid);
		return "redirect:/";
		
	}
	
	
	@RequestMapping("/modifyplayer")
	public String modifyhandler(@RequestParam("myid") int pid,ModelMap mymap)
	{
	  Player playerfound=playerdao.findPlayerbyid(pid);
	  mymap.put("playerold",playerfound);
	  
	  
	  List<Player> players=playerdao.getPlayers();
		mymap.put("playerslist",players);
		
	  return "index";
	
	}
	
	@RequestMapping("/updateplayer")
	public String updatehandler(@ModelAttribute("playerupd") Player playernew)
	{
		playerdao.updatePlayer(playernew);
		
		return "redirect:/";
		
	}
	
	
	
}
