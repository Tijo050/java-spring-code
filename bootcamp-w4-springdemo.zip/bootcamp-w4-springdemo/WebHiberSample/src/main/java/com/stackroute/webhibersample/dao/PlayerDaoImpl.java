package com.stackroute.webhibersample.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.stackroute.webhibersample.model.Player;


@Repository
@Transactional

public class PlayerDaoImpl implements PlayerDao{
	
	
	SessionFactory sessionfactory;
	
	@Autowired
	PlayerDaoImpl(SessionFactory sessfact)
	{
		this.sessionfactory=sessfact;
	}

	public boolean addPlayer(Player playerobj) {
		
		sessionfactory.getCurrentSession().save(playerobj);
		return true;
	}

	public List<Player> getPlayers() {

List<Player> playerlist=sessionfactory.getCurrentSession().createQuery("from Player").list();

		return playerlist;
	}

	public Player findPlayerbyid(int playerid) {
		
		Player playerobj=(Player)sessionfactory.getCurrentSession().createQuery("from Player where playerid=" +playerid).uniqueResult();
		// TODO Auto-generated method stub
		return playerobj;
	}

	public boolean deletePlayer(int playerid) {
		
		Player playerexist=findPlayerbyid(playerid);
		if(playerexist!=null)
		{ 
			 sessionfactory.getCurrentSession().delete(playerexist);
			 	return true;
		} 
		// TODO Auto-generated method stub
		return false;
	}

	public boolean updatePlayer(Player playertoup) {
		
	 Player playerexist=findPlayerbyid(playertoup.getPlayerid());
	 
	 playerexist.setCountry(playertoup.getCountry());
	 playerexist.setPlayername(playertoup.getPlayername());
	 
	 sessionfactory.getCurrentSession().update(playerexist);
		return true;
	}

}
