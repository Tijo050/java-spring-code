
package com.stackroute.SimpleJavaApp;

public class Account {
	
	String accounttype;
	int minamount;
	public String getAccounttype() {
		return accounttype;
	}
	public void setAccounttype(String accounttype) {
		this.accounttype = accounttype;
	}
	public int getMinamount() {
		return minamount;
	}
	public void setMinamount(int minamount) {
		this.minamount = minamount;
	}
	

}
