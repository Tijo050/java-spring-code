package com.stackroute.SimpleJavaApp.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.stackroute.SimpleJavaApp.Account;
import com.stackroute.SimpleJavaApp.Customer;

@Configuration
public class MyConfiguration {
	
	// <bean id="accbean" class="Account">
	
	
	@Bean("accbean")
	@Scope("prototype")
	
	public Account getAccount()
	{
		Account accountobj=new Account();
		accountobj.setAccounttype("Savings");
		accountobj.setMinamount(5000);
		return accountobj;
	}

	@Bean("customerbean")
	public Customer getCustomer()
	{
		Customer customer=new Customer();
		customer.setCustomername("Mary");
		
		return customer;
	}
	
}
