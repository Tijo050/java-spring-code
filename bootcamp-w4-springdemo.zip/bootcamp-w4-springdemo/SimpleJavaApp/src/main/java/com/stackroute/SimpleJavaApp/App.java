package com.stackroute.SimpleJavaApp;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.stackroute.SimpleJavaApp.config.MyConfiguration;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	
    	ApplicationContext appcontext=new AnnotationConfigApplicationContext(MyConfiguration.class);
    	
    	 
    	Customer custobj=appcontext.getBean("customerbean",Customer.class);
    	System.out.println(custobj.getCustomername());
    	
    	System.out.println(custobj.getMyaccount().getAccounttype());
    	
    	
 //   	Customer custobj=Myconfigurate.getCustomer();
    	
    	
    }
}
