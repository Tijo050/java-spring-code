package com.stackroute.SimpleJavaApp;

import org.springframework.beans.factory.annotation.Autowired;

public class Customer {
	
	String customername;
	
	@Autowired
	Account myaccount;
	
	public String getCustomername() {
		return customername;
	}
	public void setCustomername(String customername) {
		this.customername = customername;
	}
	public Account getMyaccount() {
		return myaccount;
	}
	public void setMyaccount(Account myaccount) {
		this.myaccount = myaccount;
	}
	

}
